<html>
	<head>	
		<link rel="stylesheet" type="text/css" href="style.css">
		</head>
	<body>
		<div id="menu-strip">
			<span id="sub-menu"><b>Home</b> <span>
			<span id="sub-menu"><b>About Us</b> <span>
			<span id="sub-menu"><b>Product Inforamtion</b> <span>
			<span id="sub-menu"><b>Sign In</b> <span>
			<span id="sub-menu"><b>Support</b> <span>
		</div>
	</body>
</html>