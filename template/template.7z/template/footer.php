<html>
	<head>	
		<link rel="stylesheet" type="text/css" href="style.css">
		</head>
	<body>
		<div id="footer">
			<b>Copyright &copy; 2015 All rights Reserved<b/>
		</div>
	</body>
</html>
