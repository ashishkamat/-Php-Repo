<html>
	<head>	
		<link rel="stylesheet" type="text/css" href="style.css">
		</head>
	<body>
		<div id="header">
			<img src="header.jpg" height="250px" width="98%">
		</div>
	</body>
</html>