<html>
	<head>	
		<link rel="stylesheet" type="text/css" href="style.css">
		</head>
	<body>
		<div id="sidebar">
				<ol>
				<li><a href="Page1.php">Page 1</li>
				<li><a href="Page2.php">Page 2</li>
				</ol>		
		</div>
	</body>
</html>