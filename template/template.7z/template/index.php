<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>

<body>
	
<?php include "header.php"; ?>
<?php include "menu.php"; ?>
	<div id ="main">	
<?php include "sidebar.php";?>
		<div id="content"><h1> Main Content goes here</h1></div> 
	</div>

<?php include "footer.php";?>
	
</body>
</html>